package Java_Swing_To_Do_App;
import javax.swing.*;
import java.awt.*;

public class SmartToDoApp extends JFrame {

    private DefaultListModel<String> taskListModel;
    private JList<String> taskList;
    private JTextField taskInput;

    public SmartToDoApp() {
        setTitle("Smart To-Do / Chat-like App");
        setSize(500, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        taskListModel = new DefaultListModel<>();
        taskList = new JList<>(taskListModel);
        taskList.setFont(new Font("Arial", Font.PLAIN, 16));

        taskInput = new JTextField();
        taskInput.setFont(new Font("Arial", Font.PLAIN, 16));

        JButton addButton = new JButton("Add");
        addButton.setFont(new Font("Arial", Font.BOLD, 14));
        addButton.addActionListener(e -> handleAdd());

        JButton deleteButton = new JButton("Delete");
        deleteButton.setFont(new Font("Arial", Font.BOLD, 14));
        deleteButton.addActionListener(e -> handleDelete());

        JButton updateButton = new JButton("Update");
        updateButton.setFont(new Font("Arial", Font.BOLD, 14));
        updateButton.addActionListener(e -> handleUpdate());

        JPanel inputPanel = new JPanel(new BorderLayout(5, 5));
        inputPanel.add(taskInput, BorderLayout.CENTER);
        inputPanel.add(addButton, BorderLayout.EAST);

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(deleteButton);
        buttonPanel.add(updateButton);

        add(inputPanel, BorderLayout.NORTH);
        add(new JScrollPane(taskList), BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
    }

    /**
     * Add: processes input (math or text) and adds to list
     */
    private void handleAdd() {
        String input = taskInput.getText().trim();
        if (input.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter something.");
            return;
        }

        try {
            double result = evalMath(input);
            taskListModel.addElement(input + " = " + result);
        } catch (Exception e) {
            taskListModel.addElement(input);
        }

        taskInput.setText("");
    }

    /**
     * Delete: removes selected item from list
     */
    private void handleDelete() {
        int selectedIndex = taskList.getSelectedIndex();
        if (selectedIndex != -1) {
            taskListModel.remove(selectedIndex);
        } else {
            JOptionPane.showMessageDialog(this, "Please select an item to delete.");
        }
    }

    /**
     * Update: edits selected item with new value from input
     */
    private void handleUpdate() {
        int selectedIndex = taskList.getSelectedIndex();
        String newValue = taskInput.getText().trim();

        if (selectedIndex == -1) {
            JOptionPane.showMessageDialog(this, "Please select an item to update.");
            return;
        }
        if (newValue.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter a new value.");
            return;
        }

        try {
            double result = evalMath(newValue);
            taskListModel.set(selectedIndex, newValue + " = " + result);
        } catch (Exception e) {
            taskListModel.set(selectedIndex, newValue);
        }

        taskInput.setText("");
    }

    /**
     * Evaluates math expressions like 3+4, 5*2, etc.
     */
    private double evalMath(String expression) {
        try {
            return Double.parseDouble(
                new javax.script.ScriptEngineManager()
                    .getEngineByName("JavaScript")
                    .eval(expression).toString()
            );
        } catch (Exception e) {
            throw new IllegalArgumentException("Not a math expression");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            SmartToDoApp app = new SmartToDoApp();
            app.setVisible(true);
        });
    }
}
